package com.eldanior.system.classes.definitions;

import com.eldanior.system.classes.models.ClassModel;
import com.eldanior.system.config.configs.ClassType;
import com.eldanior.system.config.configs.Rarity;
import com.eldanior.system.config.configs.WeaponMastery;

import java.util.List;

public class Mage extends ClassModel {

    public Mage() {
        super(
                "mage",
                "Mage",
                "Un maitre des arcanes utilisant le mana.",
                Rarity.COMMON,
                ClassType.MAGE,
                List.of(),
                List.of(WeaponMastery.STAFF),
                List.of(),
                120,
                false,
                3, 3, 10000, 2, 2, 3
        );
    }
}