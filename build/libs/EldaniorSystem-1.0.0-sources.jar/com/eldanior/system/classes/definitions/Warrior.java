package com.eldanior.system.classes.definitions;

import com.eldanior.system.classes.models.ClassModel;
import com.eldanior.system.config.configs.ClassType;
import com.eldanior.system.config.configs.Rarity;

public class Warrior extends ClassModel {

    public Warrior() {
        super(
                "warrior",
                "Guerrier",
                "Un combattant robuste specialise dans le corps a corps.",
                Rarity.COMMON,
                ClassType.WARRIOR,
                "templier",
                120,
                false,
                25, 25, 2, 25, 30, 30
        );
    }
}

//5, 5, 2, 2, 3, 1 ==> default
//25, 25, 2, 25, 30, 30 ==> N°40