package com.eldanior.system.config.Player;

import com.eldanior.system.classes.ClassManager;
import com.eldanior.system.classes.models.ClassModel;
import com.eldanior.system.skills.skillsInteraction.PassiveSkill;
import com.hypixel.hytale.codec.Codec;
import com.hypixel.hytale.codec.KeyedCodec;
import com.hypixel.hytale.codec.builder.BuilderCodec;
import com.hypixel.hytale.component.Component;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

import javax.annotation.Nullable;
import java.util.*;

public class PlayerLevelData implements Component<EntityStore> {

    public static ComponentType<EntityStore, PlayerLevelData> TYPE;

    // --- Variables ---
    private int level = 1;
    private int experience = 0;
    private int attributePoints = 0;

    // Identité
    private String playerClass = "Novice";
    private String classId = "novice";
    private String currentTitle = "";
    private List<String> unlockedTitles = new ArrayList<>();
    private String guildRank = "F";
    private String activeSkillId = "";

    // Stats de BASE (Investies par le joueur)
    private int strength = 1;
    private int endurance = 1;
    private int agility = 1;
    private int vitality = 1;
    private int intelligence = 1;
    private int luck = 1;
    private long money = 1000;
    private UUID lastVictimUUID;
    private int hauntingThrustStacks;
    private transient long lastDamageTakenTime = 0;

    private List<String> unlockedSkills = new ArrayList<>();
    private Set<String> enabledSkills = new HashSet<>();
    private transient Map<String, Long> cooldowns = new HashMap<>();

    public PlayerLevelData() {
        this.unlockedTitles.add("Novice");
    }

    public int getRequiredExperience() {
        return (int) (100 + 140 * (level - 1) + 10L * (level - 1) * (level - 1));
    }

    public void addExperience(int amount) {
        this.experience += amount;
        while (this.experience >= getRequiredExperience()) {
            this.experience -= getRequiredExperience();
            this.level++;
            this.attributePoints += 3;
        }
    }

    public float getExperienceProgress() {
        return (float) this.experience / getRequiredExperience();
    }

    public boolean hasEnoughMana(float amount) {
        return true;
    }

    public boolean canCast(String skillId) {
        if (!cooldowns.containsKey(skillId)) return true;
        return System.currentTimeMillis() >= cooldowns.get(skillId);
    }

    public void applyCooldown(String skillId, float durationSeconds) {
        long readyTime = System.currentTimeMillis() + (long)(durationSeconds * 1000);
        cooldowns.put(skillId, readyTime);
    }

    public long getRemainingCooldown(String skillId) {
        if (!cooldowns.containsKey(skillId)) return 0;
        return Math.max(0, cooldowns.get(skillId) - System.currentTimeMillis());
    }

    // --- LE CODEC ---
    public static final BuilderCodec<PlayerLevelData> CODEC = BuilderCodec.builder(PlayerLevelData.class, PlayerLevelData::new)
            .append(new KeyedCodec<>("Level", Codec.INTEGER), (data, v) -> data.level = v, data -> data.level).add()
            .append(new KeyedCodec<>("Experience", Codec.INTEGER), (data, v) -> data.experience = v, data -> data.experience).add()
            .append(new KeyedCodec<>("AttributePoints", Codec.INTEGER), (data, v) -> data.attributePoints = v, data -> data.attributePoints).add()
            .append(new KeyedCodec<>("PlayerClass", Codec.STRING), (data, v) -> data.playerClass = v, data -> data.playerClass).add()
            .append(new KeyedCodec<>("ClassId", Codec.STRING), (data, v) -> data.classId = v, data -> data.classId).add()
            .append(new KeyedCodec<>("CurrentTitle", Codec.STRING), (data, v) -> data.currentTitle = v, data -> data.currentTitle).add()
            .append(new KeyedCodec<>("GuildRank", Codec.STRING), (data, v) -> data.guildRank = v, data -> data.guildRank).add()
            .append(new KeyedCodec<>("Strength", Codec.INTEGER), (data, v) -> data.strength = v, data -> data.strength).add()
            .append(new KeyedCodec<>("Endurance", Codec.INTEGER), (data, v) -> data.endurance = v, data -> data.endurance).add()
            .append(new KeyedCodec<>("Agility", Codec.INTEGER), (data, v) -> data.agility = v, data -> data.agility).add()
            .append(new KeyedCodec<>("Vitality", Codec.INTEGER), (data, v) -> data.vitality = v, data -> data.vitality).add()
            .append(new KeyedCodec<>("Intelligence", Codec.INTEGER), (data, v) -> data.intelligence = v, data -> data.intelligence).add()
            .append(new KeyedCodec<>("Luck", Codec.INTEGER), (data, v) -> data.luck = v, data -> data.luck).add()
            .append(new KeyedCodec<>("Money", Codec.LONG), (data, v) -> data.money = v, data -> data.money).add()
            .append(new KeyedCodec<>("UnlockedSkills", Codec.STRING), (data, value) -> {
                data.unlockedSkills = new ArrayList<>();
                if (value != null && !value.isEmpty()) {
                    data.unlockedSkills.addAll(Arrays.asList(value.split(",")));
                }
            }, (data) -> String.join(",", data.unlockedSkills)).add()
            .append(new KeyedCodec<>("EnabledSkills", Codec.STRING), (data, value) -> {
                data.enabledSkills = new HashSet<>();
                if (value != null && !value.isEmpty()) {
                    data.enabledSkills.addAll(Arrays.asList(value.split(",")));
                }
            }, (data) -> String.join(",", data.enabledSkills)).add()
            .append(new KeyedCodec<>("UnlockedTitles", Codec.STRING), (data, value) -> {
                data.unlockedTitles = new ArrayList<>();
                if (value != null && !value.isEmpty()) {
                    data.unlockedTitles.addAll(Arrays.asList(value.split(",")));
                }
            }, (data) -> String.join(",", data.unlockedTitles)).add()
            .build();

    // --- Méthode CLONE ---
    @Nullable
    @Override
    public Component<EntityStore> clone() {
        PlayerLevelData copy = new PlayerLevelData();
        copy.level = this.level;
        copy.experience = this.experience;
        copy.attributePoints = this.attributePoints;
        copy.playerClass = this.playerClass;
        copy.classId = this.classId;
        copy.currentTitle = this.currentTitle;
        copy.guildRank = this.guildRank;
        copy.strength = this.strength;
        copy.endurance = this.endurance;
        copy.agility = this.agility;
        copy.vitality = this.vitality;
        copy.intelligence = this.intelligence;
        copy.luck = this.luck;
        copy.money = this.money;
        copy.lastVictimUUID = this.lastVictimUUID;
        copy.hauntingThrustStacks = this.hauntingThrustStacks;
        copy.lastDamageTakenTime = this.lastDamageTakenTime;


        copy.enabledSkills = new HashSet<>(this.enabledSkills);
        if (this.unlockedTitles != null) {
            copy.unlockedTitles = new ArrayList<>(this.unlockedTitles);
        }
        if (this.unlockedSkills != null) {
            copy.unlockedSkills = new ArrayList<>(this.unlockedSkills);
        }

        copy.cooldowns = new HashMap<>(this.cooldowns);

        return copy;
    }

    // ================= SKILLS METHODS =================

    public List<String> getUnlockedSkills() { return unlockedSkills; }
    public void learnSkill(String skillId) {
        if (!unlockedSkills.contains(skillId)) unlockedSkills.add(skillId);
    }
    public void forgetAllSkills() {
        unlockedSkills.clear();
        enabledSkills.clear();
    }
    public String getActiveSkillId() { return activeSkillId; }
    public void setActiveSkillId(String id) { this.activeSkillId = id; }

    // === NOUVEAU GETTER DYNAMIQUE DES PASSIFS ===
    public List<PassiveSkill> getActivePassives() {
        List<PassiveSkill> activePassives = new ArrayList<>();

        // 1. Récupération des passifs "Innés" de la classe
        ClassModel model = ClassManager.get(this.classId);
        if (model != null && model.getSkillsPassiveIds() != null) {
            activePassives.addAll(model.getSkillsPassiveIds());
        }

        // 2. Récupération des passifs "Appris" via les parchemins
        for (String skillId : this.unlockedSkills) {
            try {
                // On essaie de convertir le String (ex: "IRON_SKIN") en Enum
                PassiveSkill learnedPassive = PassiveSkill.valueOf(skillId.toUpperCase());

                // On l'ajoute seulement s'il n'est pas déjà dans la liste
                if (!activePassives.contains(learnedPassive)) {
                    activePassives.add(learnedPassive);
                }
            } catch (IllegalArgumentException e) {
                // Ce n'est pas grave ! Ça veut dire que ce skillId est un sort ACTIF (comme "fireball")
                // et pas un passif. On l'ignore simplement pour le combat passif.
            }
        }

        return activePassives;
    }

    public void removeSkill(String skillId) {
        // On la retire des compétences débloquées
        unlockedSkills.remove(skillId);

        // Par sécurité, on la retire aussi des compétences actives/équipées !
        enabledSkills.remove(skillId);
    }

    // ================= GETTERS (Identité & Base) =================
    public int getLevel() { return level; }
    public int getExperience() { return experience; }
    public int getAttributePoints() { return attributePoints; }
    public String getPlayerClass() { return playerClass; }
    public String getPlayerClassId() { return classId; }
    public String getCurrentTitle() { return currentTitle; }
    public List<String> getUnlockedTitles() { return unlockedTitles; }
    public String getGuildRank() { return guildRank; }
    public long getMoney() { return money; }

    // Points investis par le joueur (sans bonus de classe)
    public int getStrength() { return strength; }
    public int getEndurance() { return endurance; }
    public int getAgility() { return agility; }
    public int getVitality() { return vitality; }
    public int getIntelligence() { return intelligence; }
    public int getLuck() { return luck; }

    // ================= GETTERS (TOTAUX AVEC BONUS DE CLASSE) =================
    public int getTotalStrength() { return strength + getClassBonusStr(); }
    public int getTotalEndurance() { return endurance + getClassBonusEnd(); }
    public int getTotalAgility() { return agility + getClassBonusAgl(); }
    public int getTotalVitality() { return vitality + getClassBonusVit(); }
    public int getTotalIntelligence() { return intelligence + getClassBonusInt(); }
    public int getTotalLuck() { return luck + getClassBonusLck(); }

    public int getMaxMana() { return getTotalIntelligence() * 10; }
    public int getMaxHealth() { return getTotalVitality() * 10; }

    // Utilitaires internes pour récupérer le bonus de classe
    private int getClassBonusStr() {
        ClassModel model = ClassManager.get(this.classId);
        return model != null ? model.getBonusStr() : 0;
    }
    private int getClassBonusEnd() {
        ClassModel model = ClassManager.get(this.classId);
        return model != null ? model.getBonusEnd() : 0;
    }
    private int getClassBonusAgl() {
        ClassModel model = ClassManager.get(this.classId);
        return model != null ? model.getBonusAgl() : 0;
    }
    private int getClassBonusVit() {
        ClassModel model = ClassManager.get(this.classId);
        return model != null ? model.getBonusVit() : 0;
    }
    private int getClassBonusInt() {
        ClassModel model = ClassManager.get(this.classId);
        return model != null ? model.getBonusInt() : 0;
    }
    private int getClassBonusLck() {
        ClassModel model = ClassManager.get(this.classId);
        return model != null ? model.getBonusLck() : 0;
    }

    public UUID getLastVictimUUID() { return lastVictimUUID; }
    public void setLastVictimUUID(UUID lastVictimUUID) { this.lastVictimUUID = lastVictimUUID; }
    public int getHauntingThrustStacks() { return hauntingThrustStacks; }
    public void setHauntingThrustStacks(int stacks) { this.hauntingThrustStacks = stacks; }
    public long getLastDamageTakenTime() { return lastDamageTakenTime; }
    public void setLastDamageTakenTime(long time) { this.lastDamageTakenTime = time; }

    // ================= SETTERS =================
    public void setLevel(int level) { this.level = level; }
    public void setExperience(int experience) { this.experience = experience; }
    public void setAttributePoints(int points) { this.attributePoints = points; }
    public void setPlayerClass(String playerClass) { this.playerClass = playerClass; }
    public void setPlayerClassId(String classId) { this.classId = classId; }
    public void setCurrentTitle(String title) { this.currentTitle = title; }
    public void setGuildRank(String guildRank) { this.guildRank = guildRank; }

    // Ces setters ne modifient que les points de base (ex: lors d'un Level Up)
    public void setStrength(int strength) { this.strength = strength; }
    public void setEndurance(int endurance) { this.endurance = endurance; }
    public void setAgility(int agility) { this.agility = agility; }
    public void setVitality(int vitality) { this.vitality = vitality; }
    public void setIntelligence(int intelligence) { this.intelligence = intelligence; }
    public void setLuck(int luck) { this.luck = luck; }
    public void setMoney(long money) { this.money = money; }

    public void addTitle(String title) {
        if (this.unlockedTitles == null) this.unlockedTitles = new ArrayList<>();
        if (!this.unlockedTitles.contains(title)) {
            this.unlockedTitles.add(title);
        }
    }

    public void addMoney(long amount) { this.money += amount; }
    public void removeMoney(long amount) { this.money = Math.max(0, this.money - amount); }
}