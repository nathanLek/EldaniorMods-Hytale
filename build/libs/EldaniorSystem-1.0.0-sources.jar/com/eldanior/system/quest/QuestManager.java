package com.eldanior.system.quest;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class QuestManager {

    private static final Map<String, QuestModel> allQuests = new LinkedHashMap<>();

    // Quetes actives par joueur (UUID -> liste de PlayerQuest)
    private static final Map<UUID, List<PlayerQuest>> playerQuests = new ConcurrentHashMap<>();

    // Jour courant pour les journalieres
    private static int currentDay = -1;

    // Selection aleatoire de 7 quetes journalieres pour aujourd'hui
    private static final int DAILY_SELECTION_COUNT = 7;
    private static final List<String> todaysDailyIds = new ArrayList<>();

    public static void init() {
        registerQuests();
        currentDay = getDayOfYear();
        refreshDailySelection();
        System.out.println("[Eldanior] Systeme de Quetes initialise. " + allQuests.size() + " quetes, " + todaysDailyIds.size() + " journalieres du jour.");
    }

    private static void registerQuests() {
        // Principal - Histoire
        register(new com.eldanior.system.quest.definitions.principal.MainQuest_NaissanceRoi());

        // Secondaire
        register(new com.eldanior.system.quest.definitions.secondaire.SideQuest_Explorateur());
        register(new com.eldanior.system.quest.definitions.secondaire.SideQuest_Duelliste());
        register(new com.eldanior.system.quest.definitions.secondaire.SecQuest_AncienConseiller());
        register(new com.eldanior.system.quest.definitions.secondaire.InfoQuest_Tavernier());

        // Journalieres - Chasse
        register(new com.eldanior.system.quest.definitions.journaliere.chasse.DailyChasse_Squelettes());
        register(new com.eldanior.system.quest.definitions.journaliere.chasse.DailyChasse_Zombies());

        // Journalieres - Massacre
        register(new com.eldanior.system.quest.definitions.journaliere.massacre.DailyMassacre_Carnage());
        register(new com.eldanior.system.quest.definitions.journaliere.massacre.DailyMassacre_Exterminateur());

        // Journalieres - Exploration
        register(new com.eldanior.system.quest.definitions.journaliere.exploration.DailyExplore_ChasseurCoffres());
        register(new com.eldanior.system.quest.definitions.journaliere.exploration.DailyExplore_GrandExplorateur());

        // Journalieres - Collection
        register(new com.eldanior.system.quest.definitions.journaliere.collection.DailyCollect_PetitTresor());
        register(new com.eldanior.system.quest.definitions.journaliere.collection.DailyCollect_Fortune());

        // Journalieres - Duel
        register(new com.eldanior.system.quest.definitions.journaliere.duel.DailyDuel_PremierSang());
        register(new com.eldanior.system.quest.definitions.journaliere.duel.DailyDuel_ChampionDuJour());
    }

    private static void register(QuestModel quest) {
        allQuests.put(quest.getId(), quest);
    }

    // ==================== GETTERS ====================

    public static QuestModel getQuest(String id) { return allQuests.get(id); }

    /**
     * Trouve la prochaine quete dialogue pour un NPC specifique.
     * Retourne la premiere quete non-completee de ce NPC.
     */
    public static QuestModel getNextDialogueForNpc(com.hypixel.hytale.server.core.universe.PlayerRef playerRef, String npcId) {
        UUID playerUUID = null;
        try {
            java.lang.reflect.Field f = com.hypixel.hytale.server.core.universe.PlayerRef.class.getDeclaredField("uuid");
            f.setAccessible(true);
            playerUUID = (UUID) f.get(playerRef);
        } catch (Exception ignored) {}

        List<PlayerQuest> owned = playerUUID != null ? getPlayerQuests(playerUUID) : List.of();
        Set<String> completedIds = new HashSet<>();
        for (PlayerQuest pq : owned) {
            if (pq.isCompleted()) completedIds.add(pq.getQuestId());
        }

        Set<String> ownedIds = new HashSet<>();
        for (PlayerQuest pq : owned) ownedIds.add(pq.getQuestId());

        for (QuestModel quest : allQuests.values()) {
            if (!npcId.equals(quest.getNpcGiverId())) continue;
            if (completedIds.contains(quest.getId())) continue;
            if (!(quest instanceof com.eldanior.system.quest.dialogue.NpcDialogueQuest nq)) continue;

            // Si la quete a un prerequis (unlocksQuestId d'une autre quete),
            // verifier que le joueur l'a bien debloquee (= la quete prerequise est completee)
            // Chercher si une autre quete doit etre completee pour debloquer celle-ci
            boolean locked = false;
            for (QuestModel other : allQuests.values()) {
                if (other instanceof com.eldanior.system.quest.dialogue.NpcDialogueQuest otherNq) {
                    if (quest.getId().equals(otherNq.getUnlocksQuestId())) {
                        // "other" doit etre completee pour debloquer "quest"
                        if (!completedIds.contains(other.getId())) {
                            locked = true;
                        }
                        break;
                    }
                }
            }
            if (locked) continue;

            return quest;
        }
        return null;
    }
    public static Collection<QuestModel> getAllQuests() { return allQuests.values(); }

    // Cooldowns par joueur: questId -> timestamp de fin de cooldown
    private static final Map<UUID, Map<String, Long>> cooldowns = new ConcurrentHashMap<>();

    public static List<QuestModel> getAvailableQuests(UUID playerUUID) {
        List<QuestModel> available = new ArrayList<>();
        List<PlayerQuest> owned = getPlayerQuests(playerUUID);
        Set<String> ownedIds = new HashSet<>();
        for (PlayerQuest pq : owned) ownedIds.add(pq.getQuestId());

        Map<String, Long> playerCooldowns = cooldowns.computeIfAbsent(playerUUID, k -> new HashMap<>());
        long now = System.currentTimeMillis();

        for (QuestModel quest : allQuests.values()) {
            if (ownedIds.contains(quest.getId())) continue;

            // Journalieres : seulement celles selectionnees aujourd'hui
            if (quest.isDaily() && !todaysDailyIds.contains(quest.getId())) continue;

            // Verifier cooldown
            if (quest.getCooldownMinutes() > 0) {
                Long cdEnd = playerCooldowns.get(quest.getId());
                if (cdEnd != null && now < cdEnd) continue; // Encore en cooldown
            }

            // Pour les principales: verifier la chaine
            if (quest.isMainStory() && !isMainQuestAvailable(quest.getId(), owned)) continue;

            available.add(quest);
        }
        return available;
    }

    /** Selectionne aleatoirement DAILY_SELECTION_COUNT quetes journalieres pour aujourd'hui.
     *  Le seed est base sur le jour, donc tous les joueurs voient la meme selection. */
    private static void refreshDailySelection() {
        todaysDailyIds.clear();
        List<String> allDailies = new ArrayList<>();
        for (QuestModel quest : allQuests.values()) {
            if (quest.isDaily()) allDailies.add(quest.getId());
        }
        // Seed fixe par jour = meme selection pour tous les joueurs
        Random dayRandom = new Random(currentDay * 31L + 2026);
        Collections.shuffle(allDailies, dayRandom);
        int count = Math.min(DAILY_SELECTION_COUNT, allDailies.size());
        todaysDailyIds.addAll(allDailies.subList(0, count));
        System.out.println("[Quests] Journalieres du jour: " + todaysDailyIds);
    }

    public static List<String> getTodaysDailyIds() { return todaysDailyIds; }

    public static void setCooldown(UUID playerUUID, String questId, int minutes) {
        if (minutes <= 0) return;
        cooldowns.computeIfAbsent(playerUUID, k -> new HashMap<>())
                .put(questId, System.currentTimeMillis() + (minutes * 60000L));
    }

    public static long getCooldownEnd(UUID playerUUID, String questId) {
        Map<String, Long> playerCooldowns = cooldowns.get(playerUUID);
        if (playerCooldowns == null) return 0;
        Long end = playerCooldowns.get(questId);
        return end != null ? end : 0;
    }

    public static String serializeCooldowns(UUID playerUUID) {
        Map<String, Long> playerCooldowns = cooldowns.get(playerUUID);
        if (playerCooldowns == null || playerCooldowns.isEmpty()) return "";
        long now = System.currentTimeMillis();
        StringBuilder sb = new StringBuilder();
        for (var entry : playerCooldowns.entrySet()) {
            if (entry.getValue() > now) { // Seulement les cooldowns actifs
                if (sb.length() > 0) sb.append("|");
                sb.append(entry.getKey()).append("=").append(entry.getValue());
            }
        }
        return sb.toString();
    }

    public static void deserializeCooldowns(UUID playerUUID, String data) {
        if (data == null || data.isEmpty()) return;
        Map<String, Long> playerCooldowns = cooldowns.computeIfAbsent(playerUUID, k -> new HashMap<>());
        long now = System.currentTimeMillis();
        for (String entry : data.split("\\|")) {
            String[] parts = entry.split("=");
            if (parts.length == 2) {
                try {
                    long end = Long.parseLong(parts[1]);
                    if (end > now) { // Seulement si pas expiré
                        playerCooldowns.put(parts[0], end);
                    }
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    private static boolean isMainQuestAvailable(String questId, List<PlayerQuest> owned) {
        if ("main_1".equals(questId)) return true; // Premiere quete toujours dispo
        // Chercher la quete precedente qui pointe vers celle-ci
        for (QuestModel q : allQuests.values()) {
            if (questId.equals(q.getNextQuestId())) {
                // La precedente doit etre completee
                for (PlayerQuest pq : owned) {
                    if (pq.getQuestId().equals(q.getId()) && pq.isCompleted()) return true;
                }
                return false;
            }
        }
        return true;
    }

    // ==================== PLAYER QUESTS ====================

    public static List<PlayerQuest> getPlayerQuests(UUID playerUUID) {
        return playerQuests.computeIfAbsent(playerUUID, k -> new ArrayList<>());
    }

    public static PlayerQuest getActiveQuest(UUID playerUUID) {
        for (PlayerQuest pq : getPlayerQuests(playerUUID)) {
            if (pq.isActive()) return pq;
        }
        return null;
    }

    public static boolean acceptQuest(UUID playerUUID, String questId) {
        QuestModel model = getQuest(questId);
        if (model == null) return false;

        List<PlayerQuest> quests = getPlayerQuests(playerUUID);
        for (PlayerQuest pq : quests) {
            if (pq.getQuestId().equals(questId)) return false; // Deja acceptee
        }

        PlayerQuest pq = new PlayerQuest(questId);
        quests.add(pq);
        return true;
    }

    public static boolean activateQuest(UUID playerUUID, String questId) {
        List<PlayerQuest> quests = getPlayerQuests(playerUUID);
        // Desactiver l'ancienne
        for (PlayerQuest pq : quests) {
            if (pq.isActive()) pq.setAccepted();
        }
        // Activer la nouvelle
        for (PlayerQuest pq : quests) {
            if (pq.getQuestId().equals(questId) && !pq.isCompleted()) {
                pq.setActive();
                return true;
            }
        }
        return false;
    }

    public static void abandonQuest(UUID playerUUID, String questId) {
        List<PlayerQuest> quests = getPlayerQuests(playerUUID);
        quests.removeIf(pq -> pq.getQuestId().equals(questId) && !pq.isCompleted());
    }

    // ==================== PROGRESSION ====================

    /**
     * Appele quand un mob est tue. Verifie la quete active du joueur.
     */
    public static void onMobKill(UUID playerUUID, String mobTypeId) {
        PlayerQuest active = getActiveQuest(playerUUID);
        if (active == null || active.isCompleted()) return;

        QuestModel model = getQuest(active.getQuestId());
        if (model == null) return;

        boolean progress = false;
        if (model.getType() == QuestType.MASSACRE) {
            progress = true;
        } else if (model.getType() == QuestType.CHASSE && model.getTargetId() != null) {
            if (mobTypeId.toLowerCase().contains(model.getTargetId().toLowerCase())) {
                progress = true;
            }
        }

        if (progress) {
            active.addProgress(1);
            checkCompletion(playerUUID, active, model);
        }
    }

    public static void onChestDiscovered(UUID playerUUID) {
        PlayerQuest active = getActiveQuest(playerUUID);
        if (active == null || active.isCompleted()) return;
        QuestModel model = getQuest(active.getQuestId());
        if (model == null || model.getType() != QuestType.EXPLORATION) return;
        active.addProgress(1);
        checkCompletion(playerUUID, active, model);
    }

    public static void onDuelWin(UUID playerUUID) {
        PlayerQuest active = getActiveQuest(playerUUID);
        if (active == null || active.isCompleted()) return;
        QuestModel model = getQuest(active.getQuestId());
        if (model == null || model.getType() != QuestType.DUEL) return;
        active.addProgress(1);
        checkCompletion(playerUUID, active, model);
    }

    public static void onPKKilled(UUID killerUUID, UUID pkUUID) {
        PlayerQuest active = getActiveQuest(killerUUID);
        if (active == null || active.isCompleted()) return;
        QuestModel model = getQuest(active.getQuestId());
        if (model == null || model.getType() != QuestType.EXECUTION) return;
        active.addProgress(1);
        checkCompletion(killerUUID, active, model);
    }

    private static void checkCompletion(UUID playerUUID, PlayerQuest pq, QuestModel model) {
        if (pq.getProgress() >= model.getTargetAmount()) {
            pq.setCompleted();
            // Recompenses donnees via le systeme qui appelle (DeathXPSystem etc.)
            // On stocke juste le flag completed ici
        }
    }

    // ==================== DAILY RESET ====================

    public static void checkDailyReset() {
        int today = getDayOfYear();
        if (today != currentDay) {
            currentDay = today;
            // Reset les journalieres NON completees (en cours)
            for (var entry : playerQuests.entrySet()) {
                entry.getValue().removeIf(pq -> {
                    QuestModel model = getQuest(pq.getQuestId());
                    return model != null && model.isDaily() && !pq.isCompleted();
                });
            }
            // Nouvelle selection aleatoire
            refreshDailySelection();
            System.out.println("[Quests] Nouveau jour ! Journalieres resetees + nouvelle selection.");
        }
    }

    private static int getDayOfYear() {
        return java.time.LocalDate.now().getDayOfYear();
    }

    // ==================== SERIALIZATION ====================

    public static String serializePlayerQuests(UUID playerUUID) {
        List<PlayerQuest> quests = getPlayerQuests(playerUUID);
        StringBuilder sb = new StringBuilder();
        for (PlayerQuest pq : quests) {
            if (sb.length() > 0) sb.append("|");
            sb.append(pq.serialize());
        }
        return sb.toString();
    }

    public static void deserializePlayerQuests(UUID playerUUID, String data) {
        if (data == null || data.isEmpty()) return;
        List<PlayerQuest> quests = getPlayerQuests(playerUUID);
        quests.clear();
        for (String entry : data.split("\\|")) {
            PlayerQuest pq = PlayerQuest.deserialize(entry);
            if (pq != null) quests.add(pq);
        }
    }
}
