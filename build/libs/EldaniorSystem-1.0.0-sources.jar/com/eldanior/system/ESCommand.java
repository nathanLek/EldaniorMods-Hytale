package com.eldanior.system;

import com.eldanior.system.Inventory.commands.InventoryCommand;
import com.eldanior.system.Leveling.commands.*;
import com.eldanior.system.TreasureChest.commands.DeleteTreasureCommand;
import com.eldanior.system.TreasureChest.commands.TreasureConfigCommand;
import com.eldanior.system.classes.commands.ClassInfoCommand;
import com.eldanior.system.classes.commands.SetClassCommand;
import com.eldanior.system.skills.commands.GiveRelicCommand;
import com.eldanior.system.skills.commands.WithdrawCommand;
import com.eldanior.system.titles.commands.TitleListCommand;
import com.eldanior.system.titles.commands.TitleOneArgCommand;
import com.eldanior.system.titles.commands.TitleTwoArgCommand;
import com.eldanior.system.titles.nobility.commands.NobilityOneArgCommand;
import com.eldanior.system.titles.nobility.commands.NobilityTwoArgCommand;
import com.eldanior.system.titles.nobility.commands.NobilityStatusCommand;
import com.hypixel.hytale.server.core.command.system.basecommands.AbstractCommandCollection;

public class ESCommand extends AbstractCommandCollection {

    public ESCommand() {
        super("es", "Commande principale Eldanior System");
        this.addSubCommand(new StatusCommand());
        this.addSubCommand(new AddXPCommand());
        this.addSubCommand(new SetLevelCommand());
        this.addSubCommand(new ClassInfoCommand());
        this.addSubCommand(new SetClassCommand());
        this.addSubCommand(new GiveRelicCommand());
        this.addSubCommand(new InventoryCommand());
        this.addSubCommand(new DeleteTreasureCommand());
        this.addSubCommand(new TreasureConfigCommand());
        this.addSubCommand(new WithdrawCommand());
        this.addSubCommand(new TitleListCommand());
        this.addSubCommand(new TitleOneArgCommand());
        this.addSubCommand(new TitleTwoArgCommand());
        this.addSubCommand(new NobilityOneArgCommand());
        this.addSubCommand(new NobilityTwoArgCommand());
        this.addSubCommand(new NobilityStatusCommand());
    }

    @Override
    protected boolean canGeneratePermission() {
        return false;
    }
}