package com.eldanior.system.titles.nobility.commands;

import com.eldanior.system.EldaniorSystem;
import com.eldanior.system.config.Player.PlayerLevelData;
import com.eldanior.system.titles.nobility.NobilityManager;
import com.eldanior.system.titles.nobility.NobilityRank;
import com.eldanior.system.titles.nobility.family.FamilyManager;
import com.eldanior.system.titles.nobility.family.NobleFamilyModel;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.NameMatching;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.command.system.arguments.system.RequiredArg;
import com.hypixel.hytale.server.core.command.system.arguments.types.ArgTypes;
import com.hypixel.hytale.server.core.command.system.basecommands.AbstractAsyncCommand;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import com.hypixel.hytale.server.core.universe.Universe;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

import javax.annotation.Nonnull;
import java.lang.reflect.Field;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class NobilityTwoArgCommand extends AbstractAsyncCommand {

    private final RequiredArg<String> actionArg;
    private final RequiredArg<String> targetArg;
    private final RequiredArg<String> valueArg;

    public NobilityTwoArgCommand() {
        super("nobleset", "Noblesse (promote/setfamily)");
        this.actionArg = this.withRequiredArg("action", "promote | setfamily", ArgTypes.STRING);
        this.targetArg = this.withRequiredArg("joueur", "Joueur cible", ArgTypes.STRING);
        this.valueArg = this.withRequiredArg("valeur", "Rang ou FamilyId", ArgTypes.STRING);
    }

    @Override
    protected boolean canGeneratePermission() { return true; }

    @Nonnull
    @Override
    public CompletableFuture<Void> executeAsync(@Nonnull CommandContext ctx) {
        if (!(ctx.sender() instanceof Player sender)) return CompletableFuture.completedFuture(null);

        String action = this.actionArg.get(ctx);

        switch (action.toLowerCase()) {
            case "promote" -> handlePromote(sender, ctx);
            case "setfamily" -> handleSetFamily(sender, ctx);
            default -> sender.sendMessage(Message.raw("§cUsage : /es nobleset <promote|setfamily> <joueur> <valeur>"));
        }

        return CompletableFuture.completedFuture(null);
    }

    // ==================== PROMOTE ====================
    private void handlePromote(Player sender, CommandContext ctx) {
        String targetName = this.targetArg.get(ctx);
        String rankStr = this.valueArg.get(ctx);

        NobilityRank newRank = NobilityRank.fromString(rankStr);
        if (newRank == null || newRank == NobilityRank.ROI || newRank == NobilityRank.ROTURIER || newRank == NobilityRank.CHEVALIER) {
            sender.sendMessage(Message.raw("§cRang invalide. Utilisez : baron, comte, duc, marquis"));
            return;
        }

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                UUID senderUUID = getSenderUUID(sender);
                if (senderUUID == null || !senderUUID.equals(NobilityManager.getCurrentKingUUID())) {
                    if (!sender.hasPermission("eldanior.command.nobility.promote")) {
                        sender.sendMessage(Message.raw("§cSeul le Roi ou un Admin peut promouvoir des nobles."));
                        return;
                    }
                }

                if (!NobilityManager.canKingPromote(newRank)) {
                    int remaining = NobilityManager.getRemainingSlots(newRank);
                    sender.sendMessage(Message.raw("§cImpossible : plus de places pour le rang " + newRank.getFormattedName()
                            + " §c(reste : " + remaining + "/" + newRank.getMaxPerKingdom() + ")"));
                    return;
                }

                PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
                if (targetRef == null) {
                    sender.sendMessage(Message.raw("§cJoueur '" + targetName + "' introuvable."));
                    return;
                }

                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cLe joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) data = new PlayerLevelData();

                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setNobilityRank(newRank.name());
                copy.setDignity(newRank.getBaseDignity());
                store.putComponent(ref, type, copy);

                NobilityManager.recordKingPromotion(newRank);

                sender.sendMessage(Message.raw("§a" + targetName + " promu au rang de " + newRank.getFormattedName()));
                targetPlayer.sendMessage(Message.raw("§eVous avez ete promu au rang de " + newRank.getFormattedName() + " §e!"));

                if (newRank == NobilityRank.MARQUIS || newRank == NobilityRank.DUC) {
                    String availableFamilies = FamilyManager.getAvailableFamilyIdsForRank(newRank);
                    targetPlayer.sendMessage(Message.raw("§6Choisissez votre famille avec : §f/es nobility choosefamily <familyId>"));
                    targetPlayer.sendMessage(Message.raw("§7Familles disponibles : §e" + availableFamilies));
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== SET FAMILY ====================
    private void handleSetFamily(Player sender, CommandContext ctx) {
        if (!sender.hasPermission("eldanior.command.nobility.setfamily")) {
            UUID senderUUID;
            try { senderUUID = getSenderUUID(sender); } catch (Exception e) { return; }
            if (senderUUID == null || !senderUUID.equals(NobilityManager.getCurrentKingUUID())) {
                sender.sendMessage(Message.raw("§cSeul le Roi ou un Admin peut definir une famille."));
                return;
            }
        }

        String targetName = this.targetArg.get(ctx);
        String familyId = this.valueArg.get(ctx).toLowerCase();

        NobleFamilyModel family = FamilyManager.get(familyId);
        if (family == null) {
            sender.sendMessage(Message.raw("§cFamille '" + familyId + "' inconnue."));
            sender.sendMessage(Message.raw("§7Familles disponibles : " + FamilyManager.getAvailableIds()));
            return;
        }

        if (FamilyManager.isFamilyTaken(familyId)) {
            sender.sendMessage(Message.raw("§eAttention : Cette famille est deja prise. Attribution forcee (Admin)."));
        }

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
                if (targetRef == null) {
                    sender.sendMessage(Message.raw("§cJoueur '" + targetName + "' introuvable."));
                    return;
                }

                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cLe joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) return;

                NobilityRank rank = NobilityRank.fromString(data.getNobilityRank());
                if (rank == null || !rank.isNoble()) {
                    sender.sendMessage(Message.raw("§cCe joueur n'est pas noble."));
                    return;
                }

                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setNobleFamilyId(family.getId());
                copy.setFamilyRole("PATRIARCH");
                store.putComponent(ref, type, copy);

                FamilyManager.claimFamily(family.getId());

                sender.sendMessage(Message.raw("§a" + targetName + " est maintenant Patriarche de la famille " + family.getFormattedName()));
                targetPlayer.sendMessage(Message.raw("§eVous etes le Patriarche de la famille " + family.getFormattedName()
                        + " §7- §o" + family.getMotto()));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== UTILS ====================
    private UUID extractUUID(PlayerRef playerRef) throws Exception {
        Field uuidField = PlayerRef.class.getDeclaredField("uuid");
        uuidField.setAccessible(true);
        return (UUID) uuidField.get(playerRef);
    }

    private UUID getSenderUUID(Player sender) throws Exception {
        var ref = sender.getReference();
        if (ref == null) return null;
        Store<EntityStore> store = ref.getStore();
        PlayerRef pRef = store.getComponent(ref, PlayerRef.getComponentType());
        if (pRef == null) return null;
        return extractUUID(pRef);
    }
}