package com.eldanior.system.titles.nobility.commands;

import com.eldanior.system.EldaniorSystem;
import com.eldanior.system.config.Player.PlayerLevelData;
import com.eldanior.system.titles.nobility.NobilityManager;
import com.eldanior.system.titles.nobility.NobilityRank;
import com.eldanior.system.titles.nobility.family.FamilyManager;
import com.eldanior.system.titles.nobility.family.NobleFamilyModel;
import com.hypixel.hytale.component.ComponentType;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.server.core.Message;
import com.hypixel.hytale.server.core.NameMatching;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.command.system.arguments.system.RequiredArg;
import com.hypixel.hytale.server.core.command.system.arguments.types.ArgTypes;
import com.hypixel.hytale.server.core.command.system.basecommands.AbstractAsyncCommand;
import com.hypixel.hytale.server.core.entity.entities.Player;
import com.hypixel.hytale.server.core.universe.PlayerRef;
import com.hypixel.hytale.server.core.universe.Universe;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

import javax.annotation.Nonnull;
import java.lang.reflect.Field;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public class NobilityOneArgCommand extends AbstractAsyncCommand {

    private final RequiredArg<String> actionArg;
    private final RequiredArg<String> arg1;

    public NobilityOneArgCommand() {
        super("nobility", "Noblesse (setking/demote/knight/info/invite/setvice/choosefamily)");
        this.actionArg = this.withRequiredArg("action", "setking|demote|knight|info|invite|setvice|choosefamily", ArgTypes.STRING);
        this.arg1 = this.withRequiredArg("arg1", "Joueur ou FamilyId", ArgTypes.STRING);
    }

    @Override
    protected boolean canGeneratePermission() { return true; }

    @Nonnull
    @Override
    public CompletableFuture<Void> executeAsync(@Nonnull CommandContext ctx) {
        if (!(ctx.sender() instanceof Player sender)) return CompletableFuture.completedFuture(null);

        String action = this.actionArg.get(ctx);

        switch (action.toLowerCase()) {
            case "setking" -> handleSetKing(sender, ctx);
            case "demote" -> handleDemote(sender, ctx);
            case "knight" -> handleKnight(sender, ctx);
            case "info" -> handleInfo(sender, ctx);
            case "invite" -> handleInvite(sender, ctx);
            case "setvice" -> handleSetVice(sender, ctx);
            case "choosefamily" -> handleChooseFamily(sender, ctx);
            default -> sender.sendMessage(Message.raw("§cUsage : /es nobility <action> <joueur/familyId>"));
        }

        return CompletableFuture.completedFuture(null);
    }

    // ==================== SET KING ====================
    private void handleSetKing(Player sender, CommandContext ctx) {
        if (!sender.hasPermission("eldanior.command.nobility.setking")) {
            sender.sendMessage(Message.raw("§cErreur : Pas de permission (Admin requis)."));
            return;
        }

        String targetName = this.arg1.get(ctx);
        PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
        if (targetRef == null) {
            sender.sendMessage(Message.raw("§cErreur : Joueur '" + targetName + "' introuvable."));
            return;
        }

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cErreur : Le joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();

                UUID oldKingUUID = NobilityManager.getCurrentKingUUID();
                if (oldKingUUID != null && !oldKingUUID.equals(targetUUID)) {
                    PlayerRef oldKingRef = Universe.get().getPlayer(oldKingUUID);
                    if (oldKingRef != null) {
                        var oldRef = oldKingRef.getReference();
                        if (oldRef != null) {
                            Store<EntityStore> oldStore = oldRef.getStore();
                            PlayerLevelData oldData = oldStore.getComponent(oldRef, type);
                            if (oldData != null) {
                                PlayerLevelData oldCopy = (PlayerLevelData) oldData.clone();
                                if (oldCopy != null) {
                                    oldCopy.setNobilityRank(NobilityRank.MARQUIS.name());
                                    oldCopy.setDignity(NobilityRank.MARQUIS.getBaseDignity());
                                    oldStore.putComponent(oldRef, type, oldCopy);
                                    oldKingRef.sendMessage(Message.raw("§eVous avez ete retrogade au rang de §6Marquis§e."));
                                }
                            }
                        }
                    }
                }

                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) data = new PlayerLevelData();
                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setNobilityRank(NobilityRank.ROI.name());
                copy.setDignity(NobilityRank.ROI.getBaseDignity());
                store.putComponent(ref, type, copy);

                NobilityManager.setKing(targetUUID, targetName);

                sender.sendMessage(Message.raw("§a" + targetName + " est maintenant " + NobilityRank.ROI.getFormattedName() + " §a!"));
                targetPlayer.sendMessage(Message.raw("§6§lVous etes desormais le " + NobilityRank.ROI.getFormattedName() + " §6§l!"));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== DEMOTE ====================
    private void handleDemote(Player sender, CommandContext ctx) {
        if (!sender.hasPermission("eldanior.command.nobility.demote")) {
            UUID senderUUID;
            try { senderUUID = getSenderUUID(sender); } catch (Exception e) { return; }
            if (senderUUID == null || !senderUUID.equals(NobilityManager.getCurrentKingUUID())) {
                sender.sendMessage(Message.raw("§cSeul le Roi ou un Admin peut retrograder."));
                return;
            }
        }

        String targetName = this.arg1.get(ctx);

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
                if (targetRef == null) {
                    sender.sendMessage(Message.raw("§cJoueur '" + targetName + "' introuvable."));
                    return;
                }

                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cLe joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) return;

                NobilityRank currentRank = NobilityRank.fromString(data.getNobilityRank());
                if (currentRank == null || currentRank == NobilityRank.ROTURIER) {
                    sender.sendMessage(Message.raw("§cCe joueur est deja Roturier."));
                    return;
                }

                if (currentRank == NobilityRank.CHEVALIER) {
                    NobilityManager.removeKnight(targetUUID);
                }

                NobilityRank newRank = currentRank.previous();
                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setNobilityRank(newRank.name());
                copy.setDignity(newRank.getBaseDignity());
                if (!newRank.isNoble()) {
                    copy.setNobleFamilyId("");
                    copy.setFamilyRole("");
                }
                store.putComponent(ref, type, copy);

                sender.sendMessage(Message.raw("§a" + targetName + " retrogade a " + newRank.getFormattedName()));
                targetPlayer.sendMessage(Message.raw("§cVous avez ete retrogade a " + newRank.getFormattedName()));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== KNIGHT ====================
    private void handleKnight(Player sender, CommandContext ctx) {
        String targetName = this.arg1.get(ctx);

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                UUID senderUUID = getSenderUUID(sender);

                var senderRef = sender.getReference();
                if (senderRef == null) return;
                Store<EntityStore> senderStore = senderRef.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData senderData = senderStore.getComponent(senderRef, type);
                if (senderData == null) return;

                NobilityRank senderRank = NobilityRank.fromString(senderData.getNobilityRank());
                if (senderRank == null || !senderRank.isNoble() || senderRank == NobilityRank.CHEVALIER) {
                    sender.sendMessage(Message.raw("§cVous devez etre au moins Baron pour adouber un Chevalier."));
                    return;
                }

                if (!NobilityManager.canPromoteKnight(senderUUID, senderRank)) {
                    sender.sendMessage(Message.raw("§cVous avez atteint votre limite de Chevaliers ("
                            + senderRank.getMaxKnights() + " max pour un " + senderRank.getDisplayName() + ")."));
                    return;
                }

                PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
                if (targetRef == null) {
                    sender.sendMessage(Message.raw("§cJoueur '" + targetName + "' introuvable."));
                    return;
                }

                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cLe joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) data = new PlayerLevelData();

                NobilityRank targetRank = NobilityRank.fromString(data.getNobilityRank());
                if (targetRank != null && targetRank != NobilityRank.ROTURIER) {
                    sender.sendMessage(Message.raw("§cCe joueur a deja un rang de noblesse (" + targetRank.getFormattedName() + "§c)."));
                    return;
                }

                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setNobilityRank(NobilityRank.CHEVALIER.name());
                copy.setDignity(NobilityRank.CHEVALIER.getBaseDignity());
                if (senderData.getNobleFamilyId() != null && !senderData.getNobleFamilyId().isEmpty()) {
                    copy.setNobleFamilyId(senderData.getNobleFamilyId());
                    copy.setFamilyRole("MEMBER");
                }
                store.putComponent(ref, type, copy);

                NobilityManager.addKnight(senderUUID, targetUUID);

                sender.sendMessage(Message.raw("§a" + targetName + " est maintenant votre " + NobilityRank.CHEVALIER.getFormattedName()));
                targetPlayer.sendMessage(Message.raw("§eVous avez ete adoube " + NobilityRank.CHEVALIER.getFormattedName()
                        + " §epar " + sender.getDisplayName() + " !"));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== INFO ====================
    private void handleInfo(Player sender, CommandContext ctx) {
        String targetName = this.arg1.get(ctx);

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
                if (targetRef == null) {
                    sender.sendMessage(Message.raw("§cJoueur '" + targetName + "' introuvable."));
                    return;
                }

                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cLe joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) {
                    sender.sendMessage(Message.raw("§cAucune donnee."));
                    return;
                }

                NobilityRank rank = NobilityRank.fromString(data.getNobilityRank());
                if (rank == null) rank = NobilityRank.ROTURIER;

                sender.sendMessage(Message.raw("§6=== Noblesse de " + targetName + " ==="));
                sender.sendMessage(Message.raw("§7Rang : " + rank.getFormattedName()));
                sender.sendMessage(Message.raw("§7Dignite : §e" + data.getDignity()));

                String familyId = data.getNobleFamilyId();
                if (familyId != null && !familyId.isEmpty()) {
                    NobleFamilyModel family = FamilyManager.get(familyId);
                    if (family != null) {
                        sender.sendMessage(Message.raw("§7Famille : " + family.getFormattedName()));
                        sender.sendMessage(Message.raw("§7Devise : §o" + family.getMotto()));
                        String role = data.getFamilyRole();
                        if (role != null && !role.isEmpty()) {
                            String roleDisplay = switch (role) {
                                case "PATRIARCH" -> "§6Patriarche";
                                case "VICE" -> "§eVice-Patriarche";
                                case "MEMBER" -> "§7Membre";
                                default -> "§7" + role;
                            };
                            sender.sendMessage(Message.raw("§7Role : " + roleDisplay));
                        }
                        sender.sendMessage(Message.raw("§7Competence : §e" + family.getFamilyPassive().getDisplayName()
                                + " §8(" + family.getFamilyPassive().getDescription() + ")"));
                    }
                }

                if (rank == NobilityRank.CHEVALIER) {
                    UUID lord = NobilityManager.getLordOf(targetUUID);
                    if (lord != null) {
                        PlayerRef lordRef = Universe.get().getPlayer(lord);
                        String lordName = (lordRef != null) ? lordRef.getUsername() : "Inconnu";
                        sender.sendMessage(Message.raw("§7Seigneur : §e" + lordName));
                    }
                }

                if (rank.getMaxKnights() > 0 && rank != NobilityRank.CHEVALIER) {
                    int knightCount = NobilityManager.getKnightsOf(targetUUID).size();
                    sender.sendMessage(Message.raw("§7Chevaliers : §e" + knightCount + "/" + rank.getMaxKnights()));
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== INVITE ====================
    private void handleInvite(Player sender, CommandContext ctx) {
        String targetName = this.arg1.get(ctx);

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                var senderRef = sender.getReference();
                if (senderRef == null) return;
                Store<EntityStore> senderStore = senderRef.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData senderData = senderStore.getComponent(senderRef, type);
                if (senderData == null) return;

                if (!senderData.canInviteToFamily()) {
                    sender.sendMessage(Message.raw("§cSeul le Patriarche ou le Vice-Patriarche peut inviter."));
                    return;
                }

                String familyId = senderData.getNobleFamilyId();
                if (familyId == null || familyId.isEmpty()) {
                    sender.sendMessage(Message.raw("§cVous n'appartenez a aucune famille."));
                    return;
                }

                NobleFamilyModel family = FamilyManager.get(familyId);
                if (family == null) {
                    sender.sendMessage(Message.raw("§cFamille introuvable dans le registre."));
                    return;
                }

                PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
                if (targetRef == null) {
                    sender.sendMessage(Message.raw("§cJoueur '" + targetName + "' introuvable."));
                    return;
                }

                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cLe joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) data = new PlayerLevelData();

                if (data.getNobleFamilyId() != null && !data.getNobleFamilyId().isEmpty()) {
                    sender.sendMessage(Message.raw("§c" + targetName + " appartient deja a une famille."));
                    return;
                }

                NobilityRank targetRank = NobilityRank.fromString(data.getNobilityRank());
                if (targetRank == null || !targetRank.isNoble()) {
                    sender.sendMessage(Message.raw("§c" + targetName + " n'est pas noble. Il doit d'abord avoir un rang."));
                    return;
                }

                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setNobleFamilyId(familyId);
                copy.setFamilyRole("MEMBER");
                store.putComponent(ref, type, copy);

                sender.sendMessage(Message.raw("§a" + targetName + " a rejoint la famille " + family.getFormattedName() + " §aen tant que Membre."));
                targetPlayer.sendMessage(Message.raw("§eVous avez rejoint la famille " + family.getFormattedName()
                        + " §7- §o" + family.getMotto()));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== SET VICE ====================
    private void handleSetVice(Player sender, CommandContext ctx) {
        String targetName = this.arg1.get(ctx);

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                var senderRef = sender.getReference();
                if (senderRef == null) return;
                Store<EntityStore> senderStore = senderRef.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData senderData = senderStore.getComponent(senderRef, type);
                if (senderData == null) return;

                if (!senderData.isPatriarch()) {
                    sender.sendMessage(Message.raw("§cSeul le Patriarche peut nommer un Vice-Patriarche."));
                    return;
                }

                String familyId = senderData.getNobleFamilyId();

                PlayerRef targetRef = Universe.get().getPlayerByUsername(targetName, NameMatching.EXACT_IGNORE_CASE);
                if (targetRef == null) {
                    sender.sendMessage(Message.raw("§cJoueur '" + targetName + "' introuvable."));
                    return;
                }

                UUID targetUUID = extractUUID(targetRef);
                PlayerRef targetPlayer = Universe.get().getPlayer(targetUUID);
                if (targetPlayer == null) {
                    sender.sendMessage(Message.raw("§cLe joueur doit etre connecte."));
                    return;
                }

                var ref = targetPlayer.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) return;

                if (!familyId.equals(data.getNobleFamilyId())) {
                    sender.sendMessage(Message.raw("§c" + targetName + " n'est pas dans votre famille."));
                    return;
                }

                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setFamilyRole("VICE");
                store.putComponent(ref, type, copy);

                sender.sendMessage(Message.raw("§a" + targetName + " est maintenant Vice-Patriarche de votre famille."));
                targetPlayer.sendMessage(Message.raw("§eVous etes maintenant Vice-Patriarche de votre famille !"));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== CHOOSE FAMILY ====================
    private void handleChooseFamily(Player sender, CommandContext ctx) {
        String familyId = this.arg1.get(ctx).toLowerCase();

        NobleFamilyModel family = FamilyManager.get(familyId);
        if (family == null) {
            sender.sendMessage(Message.raw("§cFamille '" + familyId + "' inconnue."));
            sender.sendMessage(Message.raw("§7Familles disponibles : " + FamilyManager.getAvailableIds()));
            return;
        }

        if (FamilyManager.isFamilyTaken(familyId)) {
            sender.sendMessage(Message.raw("§cCette famille est deja prise par un autre joueur."));
            return;
        }

        assert sender.getWorld() != null;
        CompletableFuture.runAsync(() -> {
            try {
                var ref = sender.getReference();
                if (ref == null) return;
                Store<EntityStore> store = ref.getStore();
                ComponentType<EntityStore, PlayerLevelData> type = EldaniorSystem.get().getPlayerLevelDataType();
                PlayerLevelData data = store.getComponent(ref, type);
                if (data == null) return;

                NobilityRank rank = NobilityRank.fromString(data.getNobilityRank());
                if (rank == null || (rank != NobilityRank.MARQUIS && rank != NobilityRank.DUC)) {
                    sender.sendMessage(Message.raw("§cSeuls les Marquis et Ducs peuvent choisir une famille."));
                    return;
                }

                if (data.getNobleFamilyId() != null && !data.getNobleFamilyId().isEmpty()) {
                    sender.sendMessage(Message.raw("§cVous appartenez deja a une famille."));
                    return;
                }

                if (family.getMinimumRank() != rank) {
                    sender.sendMessage(Message.raw("§cCette famille est reservee aux " + family.getMinimumRank().getFormattedName() + "§c."));
                    sender.sendMessage(Message.raw("§7Familles pour votre rang : §e" + FamilyManager.getAvailableFamilyIdsForRank(rank)));
                    return;
                }

                PlayerLevelData copy = (PlayerLevelData) data.clone();
                if (copy == null) return;

                copy.setNobleFamilyId(family.getId());
                copy.setFamilyRole("PATRIARCH");
                store.putComponent(ref, type, copy);

                FamilyManager.claimFamily(family.getId());

                sender.sendMessage(Message.raw("§aVous etes maintenant Patriarche de la famille " + family.getFormattedName() + " §a!"));
                sender.sendMessage(Message.raw("§7Devise : §o" + family.getMotto()));
                sender.sendMessage(Message.raw("§7Competence familiale : §e" + family.getFamilyPassive().getDisplayName()));

            } catch (Exception e) {
                e.printStackTrace();
            }
        }, sender.getWorld());
    }

    // ==================== UTILS ====================
    private UUID extractUUID(PlayerRef playerRef) throws Exception {
        Field uuidField = PlayerRef.class.getDeclaredField("uuid");
        uuidField.setAccessible(true);
        return (UUID) uuidField.get(playerRef);
    }

    private UUID getSenderUUID(Player sender) throws Exception {
        var ref = sender.getReference();
        if (ref == null) return null;
        Store<EntityStore> store = ref.getStore();
        PlayerRef pRef = store.getComponent(ref, PlayerRef.getComponentType());
        if (pRef == null) return null;
        return extractUUID(pRef);
    }
}