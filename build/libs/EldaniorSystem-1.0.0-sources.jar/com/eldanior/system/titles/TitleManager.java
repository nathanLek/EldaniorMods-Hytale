package com.eldanior.system.titles;

import com.eldanior.system.config.Player.PlayerLevelData;
import com.eldanior.system.titles.definitions.*;
import com.eldanior.system.titles.models.TitleModel;

import java.util.*;

public class TitleManager {

    private static final Map<String, TitleModel> titles = new HashMap<>();

    public static void init() {
        register(new NoviceTitle());
        register(new GoblinSlayer());

        System.out.println("[Eldanior] " + titles.size() + " titres charges.");
    }

    public static void register(TitleModel model) {
        if (model != null) {
            titles.put(model.getId(), model);
        }
    }

    public static TitleModel get(String id) {
        return titles.get(id);
    }

    public static TitleModel getByDisplayName(String name) {
        for (TitleModel model : titles.values()) {
            if (model.getDisplayName().equalsIgnoreCase(name)) {
                return model;
            }
        }
        return null;
    }

    public static Collection<TitleModel> getAll() {
        return titles.values();
    }

    public static String getAvailableIds() {
        if (titles.isEmpty()) return "AUCUN (Erreur d'init)";
        return String.join(", ", titles.keySet());
    }

    /**
     * Verifie tous les titres et retourne ceux que le joueur vient de debloquer.
     */
    public static List<TitleModel> checkTitleUnlocks(PlayerLevelData data) {
        List<TitleModel> newlyUnlocked = new ArrayList<>();
        List<String> alreadyUnlocked = data.getUnlockedTitles();

        for (TitleModel title : titles.values()) {
            if (!alreadyUnlocked.contains(title.getId()) && title.checkUnlockCondition(data)) {
                newlyUnlocked.add(title);
            }
        }

        return newlyUnlocked;
    }
}