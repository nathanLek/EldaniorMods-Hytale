package com.eldanior.system.skills.skills.passives.Uncommon.Defense;

import com.eldanior.system.config.Player.PlayerLevelData;
import com.eldanior.system.skills.skillsInteraction.IPassiveCombatSkill;
import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.server.core.modules.entity.damage.Damage;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

public class SteelResolve implements IPassiveCombatSkill {

    private static final float FLAT_REDUCTION = 5.0f;

    @Override
    public void onDefend(Damage damage, PlayerLevelData victimData, Store<EntityStore> store, Ref<EntityStore> attackerRef, Ref<EntityStore> victimRef) {
        if (damage.isCancelled()) return;

        float newDamage = damage.getAmount() - FLAT_REDUCTION;
        if (newDamage < 1.0f) newDamage = 1.0f;
        damage.setAmount(newDamage);
    }
}