package com.eldanior.system.skills.skills.passives.Common.Magique;

import com.eldanior.system.config.Player.PlayerLevelData;
import com.eldanior.system.skills.skillsInteraction.IPassiveCombatSkill;
import com.hypixel.hytale.component.Ref;
import com.hypixel.hytale.component.Store;
import com.hypixel.hytale.server.core.modules.entity.damage.Damage;
import com.hypixel.hytale.server.core.universe.world.storage.EntityStore;

public class MysticVeil implements IPassiveCombatSkill {

    @Override
    public void onDefend(Damage damage, PlayerLevelData victimData, Store<EntityStore> store, Ref<EntityStore> attackerRef, Ref<EntityStore> victimRef) {
        if (damage.isCancelled()) return;

        // 15% de chance d'atténuer les dégâts
        if (Math.random() <= 0.15f) {
            // Réduit les dégâts reçus de 25%
            damage.setAmount(damage.getAmount() * 0.75f);
        }
    }
}